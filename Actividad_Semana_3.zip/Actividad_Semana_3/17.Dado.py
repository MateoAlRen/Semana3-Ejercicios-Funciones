import random

def SimularDado():
    frue = True
    while frue:
        lanzar = input("¿Lanzar el dado? (s/n): ").lower()
        if lanzar == "s":
            resultado = random.randint(1, 6)
            print(f"Salió: {resultado}")
        elif lanzar == "n":
            print("Fin.")
            frue = False
        else:
            print("Opción no válida.")

SimularDado()
