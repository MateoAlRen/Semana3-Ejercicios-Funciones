def ValidarContrasena():
    frue = True
    simbolos = "¡¿?!@#$%^&*()-_+="

    while frue:
        try:
            contrasena = input("Ingrese una contraseña: ")
            errores = []

            if len(contrasena) < 8:
                errores.append("Debe tener al menos 8 caracteres.")
            if not any(c.islower() for c in contrasena):
                errores.append("Debe tener minúsculas.")
            if not any(c.isupper() for c in contrasena):
                errores.append("Debe tener mayúsculas.")
            if not any(c.isdigit() for c in contrasena):
                errores.append("Debe tener números.")
            if not any(c in simbolos for c in contrasena):
                errores.append("Debe tener símbolos.")

            if errores:
                for e in errores:
                    print(e)
            else:
                print("Contraseña segura.")
                frue = False

        except ValueError:
            print("Error en la entrada.")

ValidarContrasena()
