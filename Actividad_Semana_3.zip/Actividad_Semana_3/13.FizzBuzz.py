def FizzBuzz():
    while True:
        try:
            numero = int(input("Ingrese un número entero: "))
            if numero % 3 == 0 and numero % 5 == 0:
                print("FizzBuzz.")
            elif numero % 3 == 0:
                print("Fizz.")
            elif numero % 5 == 0:
                print("Buzz.")
            else:
                print("El número no es múltiplo de 3 ni de 5.")
            break  
        except ValueError:
            print("Ingrese solamente números enteros.")

FizzBuzz()

