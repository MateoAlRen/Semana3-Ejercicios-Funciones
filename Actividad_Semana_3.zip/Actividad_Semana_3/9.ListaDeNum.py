def listadepares():
    numeros = []
    numerospares = []
    frue = True
    while frue:
        while len(numeros) < 5:
            try:
                num = float(input(f"Ingrese el número {len(numeros)+1}:  "))
                numeros.append(num)
            except ValueError:
                print("Ingrese solamente números.")
        for numero in numeros:
            if numero %2 == 0:
                numerospares.append(numero)
        print(numerospares)
        frue = False        
                
listadepares()