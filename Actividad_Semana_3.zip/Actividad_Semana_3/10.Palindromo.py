def palindromo():
    frue = True
    while frue:
        palabra = input("Ingrese una palabra:  ")
        prueba = palabra.lower() == palabra.lower()[::-1]
        frue = False

    if prueba == True:
        print(f"La palabra {palabra} es un palindromo.")
    elif prueba == False:
        print(f"La palabra {palabra} no es un palindromo.")

palindromo()