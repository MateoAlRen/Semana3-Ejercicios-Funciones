def GenerarContrasena():
    letras = "abcdefghijklmnopqrstuvwxyz0123456789"
    frue = True
    while frue:
        try:
            n = int(input("Longitud: "))
            if n > 0:
                clave = ""
                for i in range(n):
                    clave += letras[i % len(letras)]  
                print("Contraseña:", clave)
                frue = False
            else:
                print("Mayor que cero.")
        except:
            print("Solo números.")

GenerarContrasena()
