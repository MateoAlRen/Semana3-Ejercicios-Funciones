def Componer(func1, func2, valor):
    return func1(func2(valor))

# Ejemplo de funciones para probar:
def doblar(x):
    return x * 2

def sumar_tres(x):
    return x + 3

# Uso:
resultado = Componer(doblar, sumar_tres, 5)
print(resultado)  # (5 + 3) * 2 = 16
