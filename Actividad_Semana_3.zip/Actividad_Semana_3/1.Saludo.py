def saludo():
    frue = True
    while frue:
        Nombre = input("Ingrese su nombre:  ").strip()
        if Nombre.isalpha():
            print(f"¡Es un gusto conocerte, {Nombre}!")
            frue = False
        else:
            print("Los nombres solo tienen letras...")

saludo()