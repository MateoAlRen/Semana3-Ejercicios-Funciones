def suma():
    frue = True
    while frue:
        while True:
            try:
                Suma =  float(input("Ingresa un número:  "))
                break
            except ValueError:
                print("Por favor, solo ingrese números.")
        while True:
            try:
                Suma2 = float(input("Ingresa un segundo número:  "))
                break
            except ValueError:
                print("Por favor, solo ingrese números.")
        
        resultado = Suma + Suma2
        print(f"La suma de ambos números es de {resultado}")
        frue = False

suma()
