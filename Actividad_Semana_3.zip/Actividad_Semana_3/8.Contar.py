from collections import Counter
def contarvecesletra():
    frue = True
    while frue:
        palabra = input("Ingrese cualquier palabra:   ").lower().strip()
        if palabra.isalpha():
            contador = Counter(palabra)
            print(contador)
            frue = False
        else:
            print("Ingrese solamente letras.")

contarvecesletra()