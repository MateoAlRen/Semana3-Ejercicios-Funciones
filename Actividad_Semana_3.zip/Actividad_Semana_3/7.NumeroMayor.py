def numeromayor():
    numeros = []
    frue = True
    while frue:
        while len(numeros) < 5:
            try:
                num = float(input(f"Ingrese el número {len(numeros)+1}:  "))
                numeros.append(num)
            except ValueError:
                print("Ingrese solamente números.")
        
        numer = max(numeros)
        print(f"El numero {numer} es el más grande.")
        frue = False

numeromayor()
