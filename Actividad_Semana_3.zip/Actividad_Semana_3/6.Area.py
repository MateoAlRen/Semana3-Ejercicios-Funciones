def areatriangulo():
    frue = True
    while frue:
        while True:
            try:
                base = float(input("Ingrese la base de su triangulo:  "))
                break
            except ValueError:
                print("Ingrese solamente números.")
        while True:
            try:
                altura = float(input("Ingrese la altura de su triangulo:  "))
                break
            except ValueError:
                print("Ingrese solamente números.")
        
        resultado = base * altura
        area = resultado/2
        print(f"El area de su triangulo es de {area}.")
        frue = False

areatriangulo()