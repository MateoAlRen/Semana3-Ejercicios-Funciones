def contarvocales():
    frue = True
    vocales = "aeiou"
    contador = 0
    while frue:
        try:
            palabra = input("Ingrese una palabra:  ").lower()
            for letra in palabra:
                if letra in vocales:
                    contador += 1
            print(f"Hay {contador} vocales en la palabra")
            frue = False
        except ValueError:
            print("Ingresa solamente palabras")
            
contarvocales()