def temperatura():
    frue = True
    while frue:
        try:
            temp = float(input("Ingrese la temperatura celcius:  "))
            mult = (temp * 9/5) + 32
            print(f"La temperatura celcius {temp}° es {mult}° en farenheit.")
            frue = False
        except ValueError:
            print("Ingrese solamente números.")

temperatura()

                