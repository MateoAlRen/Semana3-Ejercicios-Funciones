import math
def factorial():
    frue = True
    while frue:
        try:
            n = int(input("Ingrese un entero positivo:  ")) 
            if n > 0:
                resultado = (math.factorial(n))
                print(resultado)
                frue = False
            elif n < 0:
                print("Solamente se pueden ingresar números positivos.")
        except ValueError:
            print("Ingrese un número.")
            
factorial()