def SumaUnicos():
    try:
        entrada = input("Ingrese números separados por espacios: ")
        numeros = [int(n) for n in entrada.split()]
        suma = sum(n for n in numeros if numeros.count(n) == 1)
        print(f"Suma de únicos: {suma}")
    except ValueError:
        print("Solo se permiten números enteros.")

SumaUnicos()
