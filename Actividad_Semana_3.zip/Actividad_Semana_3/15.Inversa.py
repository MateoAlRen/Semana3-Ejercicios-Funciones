def Inventir():
    frue = True
    while frue:
        try:
            Palabra = input("Ingrese una palabra para ser invertida:  ")
            if Palabra:
                Inverso = Palabra.lower()[::-1]
                print(f"La palabra {Palabra} es {Inverso} al revés.")
                frue = False
        except ValueError:
            print("Ingrese solamente letras.")

Inventir()