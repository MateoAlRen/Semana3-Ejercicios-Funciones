def paroimpar():
    frue = True
    while frue:
        try:
            num = int(input("Ingresa un número:  "))
            if num %2 == 0:
                print(f"El número {num} es un número par.")
                frue = False
            else:
                print(f"El número {num} es un número impar.")
        except ValueError:
            print(f"Por favor ingrese un número(entero).")

paroimpar()