def mayoriadeedad():
    frue = True
    while frue:
        try:
            edad = int(input("Ingresa tu edad:  "))
            if edad > 0 and edad < 18:
                print("Eres un menor de edad.")
                frue = False
            elif edad >= 18 and edad <= 100:
                print("Eres un mayor de edad.")
                frue = False
            else:
                print("Ingresa una edad válida.")
        except ValueError:
            print("Ingrese solo números(enteros).")

mayoriadeedad()