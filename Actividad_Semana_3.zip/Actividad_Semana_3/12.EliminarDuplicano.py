def eliminarduplicados():
    frue = True
    listanumeros = []
    while frue:
        while len(listanumeros) < 5:
            try:
                listanum = float(input("Ingrese varios números(se pedirán cinco):  "))
                if listanum:
                    listanumeros.append(listanum)
            except ValueError:
                print("Ingrese solamente números.")

        lista = set(listanumeros)
        print(lista)
        frue = False
eliminarduplicados()